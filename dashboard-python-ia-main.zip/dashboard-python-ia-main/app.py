# Bibliotecas

from dash import html, dcc, dash_table
from dash.dependencies import Input, Output, State
import dash
import dash_bootstrap_components as dbc
import pandas as pd

import plotly.graph_objects as go
import plotly.express as px

from langchain.agents.agent_types import AgentType
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from langchain_openai import ChatOpenAI

from dotenv import load_dotenv
import matplotlib.pyplot as plt
from datetime import date
import threading

load_dotenv()

# Renomear colunas para minúsculas, sem acentos e com underscores
def format_column_name(name):
    return (
        name.strip()
        .lower()
        .replace(" ", "_")
        .replace("ç", "c")
        .replace("ã", "a")
        .replace("á", "a")
        .replace("à", "a")
        .replace("â", "a")
        .replace("é", "e")
        .replace("ê", "e")
        .replace("í", "i")
        .replace("ó", "o")
        .replace("ô", "o")
        .replace("ú", "u")
        .replace("ñ", "n")
        .replace("?", "")
        .replace("(", "")
        .replace(")", "")
        .replace("/", "")
        .replace("%", "percentual")
        .replace("$", "r")
        .replace("+", "r")

    )

file_path = "./data/Indicadores_Comerciais.xlsx"
df = pd.read_excel(file_path, sheet_name='Planilha1')
df.columns = [format_column_name(col) for col in df.columns]
df['data_do_pedido'] = pd.to_datetime(df['data_do_pedido'], format='%m/%d/%Y')


# Definindo as data_do_pedidos padrão
start_date_default = date(2023, 1, 1)
end_date_default = df['data_do_pedido'].max().date()

agent_config = {
    "allow_dangerous_code": True}

agent = create_pandas_dataframe_agent(
    ChatOpenAI(temperature=0, model="gpt-4o-mini"),
    df,
    verbose=True,
    agent_type=AgentType.OPENAI_FUNCTIONS,
    **agent_config  
)


agent_response = None

def get_agent_response(user_message):
    global agent_response
    response = agent.invoke(user_message)
    if 'output' in response:
        agent_response = response['output']
    else:
        agent_response = "Não tenho certeza sobre isso. Poderia reformular a pergunta? 🤖"

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])
server = app.server

app.title = "Dashboard Comercial"

layout_receita = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.Div([
                html.Img(src="/assets/img/logo.png", className="logo-img"),
                html.Hr(),
                dbc.Label("Telas"),
                dbc.Button('Receita', href='/', className='btn-custom'),
                dbc.Button('Base Cliente', href='/base_cliente', className='btn-custom'),
                dbc.Label("Canal de Finalização"),
                dcc.Dropdown(                       
                    id='dropdown-1',
                    options=[{'label': c, 'value': c} for c in df['canal_de_finalizacao'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Nome Estrutura"),
                dcc.Dropdown(
                    id='dropdown-2',
                    options=[{'label': c, 'value': c} for c in df['nome_estrutura'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Origem do Revendedor"),
                dcc.Dropdown(
                    id='dropdown-3',
                    options=[{'label': c, 'value': c} for c in df['origem_do_revendedor'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Atividade na Base"),
                dcc.Dropdown(
                    id='dropdown-4',
                    options=[{'label': c, 'value': c} for c in df['atividade_na_base'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Segmentação Papel"),
                dcc.Dropdown(
                    id='dropdown-5',
                    options=[{'label': c, 'value': c} for c in df['segmentacao_\npapel'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Status Inadimplente"),
                dcc.Dropdown(
                    id='dropdown-6',
                    options=[{'label': c, 'value': c} for c in df['inadimplente'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Selecione o Período:"),
                dcc.DatePickerRange(
                    id='date-picker-range',
                    min_date_allowed=df['data_do_pedido'].min().date(),  
                    max_date_allowed=end_date_default,  
                    initial_visible_month=start_date_default,  
                    start_date=start_date_default,  
                    end_date=end_date_default, 
                    display_format='DD/MM/YYYY',  
                    with_portal=True,
                    className="date-picker-range",
                    start_date_placeholder_text='Start Date',
                    end_date_placeholder_text='End Date'
                ),
            ], className="sidebar")
        ], sm=2, className="sidebar-col"),
        
        dbc.Col([
            html.Div(className="dashboard-header", children=[
                html.Div(className="header-icon"),
                html.H1("Dashboard Comercial / Receita", className="header-text"),
            ]),
            html.H2("Visão Geral", className="subtitulo"),
            dbc.Row([
                dbc.Col([
                    dbc.Card(
                        dbc.CardBody([
                            html.H5("Valor Realizado (R$)", className="card-title"),
                            html.P(id="card-1-pg1", className="card-text1"),
                        ]),
                        id="dynamic-card",  # ID para atualização dinâmica
                        className="card card1",
                    )
                ], width=3),
                dbc.Col([
                    dbc.Card(
                        dbc.CardBody([
                            html.H5("Valor Previsto (R$)", className="card-title"),
                            html.P(id="card-2-pg1", className="card-text2")
                        ]),
                            className="card card1",
                    )
                ], width=3),
                dbc.Col([
                    dbc.Card(
                        dbc.CardBody([
                            html.H5("Media de Unidades Compradas", className="card-title"),
                            html.P(id="card-3-pg1", className="card-text3")
                        ]),
                            className="card card1",
                    )
                ], width=3),
                dbc.Col([
                    dbc.Card(
                        dbc.CardBody([
                            html.H5("Quantidade de Pedidos", className="card-title"),
                            html.P(id="card-4-pg1", className="card-text4")
                        ]),
                            className="card card1",
                    )
                ], width=3)
            ], className="mb-4"),
            html.H2("Indicadores Gerais", className="subtitulo"),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Valor Realizado x Previsto", className="graph-title"),
                        dcc.Graph(id='graph-1',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=8),
                dbc.Col([
                    html.Div([
                        html.H5("Segmentação Revendedores", className="graph-title"),
                        dcc.Graph(id='graph-2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=4),
            ]),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Estrutura", className="graph-title"),
                        dcc.Graph(id='graph-3',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                dbc.Col([
                    html.Div([
                        html.H5("Finalizador da Venda", className="graph-title"),
                        dcc.Graph(id='graph-4',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
            ]),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Canal", className="graph-title"),
                        dcc.Graph(id='graph-5',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),                
                dbc.Col([
                    html.Div([
                        html.H5("Marca", className="graph-title"),
                        dcc.Graph(id='graph-6',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
            ]),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Valor Realizado x Crédito Disponível (R$)", className="graph-title"),
                        dcc.Graph(id='graph-7',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=12),
            ]),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Valor Realizado x Pedidos Cancelado", className="graph-title"),
                        dcc.Graph(id='graph-8',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=12),
            ]),  
            html.H2("Indicadores Geográficos", className="subtitulo"),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Top Cidades", className="graph-title"),
                        dcc.Graph(id='graph-9',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                dbc.Col([
                    html.Div([
                        html.H5("Top Bairros", className="graph-title"),
                        dcc.Graph(id='graph-10',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
            ]),          
        ], sm=10)
    ]),
    html.Button([
        html.Img(src="/assets/img/icone_blue_ia.svg", className="button-icon"),
    ], id='open-chatbot-button', n_clicks=0, className='open-chatbot-button'),
    
    html.Div(id='chat-container', className='chat-popup', style={'display': 'none'}, children=[
        html.Div(className='chat-header', children=[
            html.Img(src="/assets/img/icone_blue_ia.svg", className="header-icon2"),
            "Data IA",
            html.Button('', id='minimize-chatbot-button', n_clicks=0, className='minimize-chatbot-button')
        ]),
        html.Div(
            id='chat-history', 
            className='chat-history-container',
            children=[
                html.Div(
                    className='message-container',
                    children=[
                        html.Div([
                            html.P("Olá! Como posso te ajudar hoje? 🤖", className='agent-message fade-in-message')
                        ])
                    ]
                )
            ]
        ),
        html.Div(className='chat-input-container', children=[
            dcc.Input(id='user-input', className='chat-input', type='text', placeholder='Digite uma mensagem...'),
            html.Button(id='send-button', n_clicks=0, className='send-button'),
            html.Div(id="output")
        ])
    ]),
    dcc.Interval(id='interval-component', interval=1*1000, n_intervals=0)
], fluid=True)


layout_base_cliente = dbc.Container([
    dbc.Row([
        dbc.Col([
            html.Div([
                html.Img(src="/assets/img/logo.png", className="logo-img"),
                html.Hr(),
                dbc.Label("Telas"),
                dbc.Button('Receita', href='/', className='btn-custom'),
                dbc.Button('Base Cliente', href='/base_cliente', className='btn-custom'),
                dbc.Label("Canal de Finalização"),
                dcc.Dropdown(                       
                    id='dropdown-1',
                    options=[{'label': c, 'value': c} for c in df['canal_de_finalizacao'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Nome Estrutura"),
                dcc.Dropdown(
                    id='dropdown-2',
                    options=[{'label': c, 'value': c} for c in df['nome_estrutura'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Origem do Revendedor"),
                dcc.Dropdown(
                    id='dropdown-3',
                    options=[{'label': c, 'value': c} for c in df['origem_do_revendedor'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Atividade na Base"),
                dcc.Dropdown(
                    id='dropdown-4',
                    options=[{'label': c, 'value': c} for c in df['atividade_na_base'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Segmentação Papel"),
                dcc.Dropdown(
                    id='dropdown-5',
                    options=[{'label': c, 'value': c} for c in df['segmentacao_\npapel'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Status Inadimplente"),
                dcc.Dropdown(
                    id='dropdown-6',
                    options=[{'label': c, 'value': c} for c in df['inadimplente'].unique()],
                    multi=True,
                    placeholder="Selecione...",
                    optionHeight=50,
                    className="mb-3 dcc-dropdown"
                ),
                dbc.Label("Selecione o Período:"),
                dcc.DatePickerRange(
                    id='date-picker-range',
                    min_date_allowed=df['data_do_pedido'].min().date(),  
                    max_date_allowed=end_date_default,  
                    initial_visible_month=start_date_default,  
                    start_date=start_date_default,  
                    end_date=end_date_default,  
                    display_format='DD/MM/YYYY',
                    with_portal=True,
                    className="date-picker-range",
                    start_date_placeholder_text='Start Date',
                    end_date_placeholder_text='End Date'
                ),
            ], className="sidebar")
        ], sm=2, className="sidebar-col"),
        
        dbc.Col([
            html.Div(className="dashboard-header", children=[
                html.Div(className="header-icon"),
                html.H1("Dashboard Comercial / Base Cliente", className="header-text"),
            ]),
            html.H2("Indicadores Gerais", className="subtitulo"),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Status Inadimplente", className="graph-title"),
                        dcc.Graph(id='graph-1-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                dbc.Col([
                    html.Div([
                        html.H5("Segmentação", className="graph-title"),
                        dcc.Graph(id='graph-2-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                ]),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Atividade", className="graph-title"),
                        dcc.Graph(id='graph-3-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                dbc.Col([
                    html.Div([
                        html.H5("Marca", className="graph-title"),
                        dcc.Graph(id='graph-4-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
               ], width=6),
            ]),
            html.H2("Rankings", className="subtitulo"),
            dbc.Row([
                dbc.Col([
                    html.Div([
                        html.H5("Top Compradores", className="graph-title"),
                        dcc.Graph(id='graph-5-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
                dbc.Col([
                    html.Div([
                        html.H5("Top Frequência", className="graph-title"),
                        dcc.Graph(id='graph-6-pg2',className="graph-container", config={'displaylogo': False,'modeBarButtonsToRemove': ['pan2d','lasso2d']}),
                    ], className="graph-wrapper")
                ], width=6),
            ]),          
        ], sm=10)
    ]),
    
    html.Button([
        html.Img(src="/assets/img/icone_blue_ia.svg", className="button-icon"),
    ], id='open-chatbot-button', n_clicks=0, className='open-chatbot-button'),

    html.Div(id='chat-container', className='chat-popup', style={'display': 'none'}, children=[
        html.Div(className='chat-header', children=[
            html.Img(src="/assets/img/icone_blue_ia.svg", className="header-icon2"),
            "Data IA",
            html.Button('', id='minimize-chatbot-button', n_clicks=0, className='minimize-chatbot-button')
        ]),
        html.Div(
            id='chat-history', 
            className='chat-history-container',
            children=[
                html.Div(
                    className='message-container',
                    children=[
                        html.Div([
                            html.P("Olá! Como posso te ajudar hoje? 🤖", className='agent-message fade-in-message')
                        ])
                    ]
                )
            ]
        ),
        html.Div(className='chat-input-container', children=[
            dcc.Input(id='user-input', className='chat-input', type='text', placeholder='Digite uma mensagem...'),
            html.Button(id='send-button', n_clicks=0, className='send-button'),
            html.Div(id="output")
        ])
    ]),
    dcc.Interval(id='interval-component', interval=1*1000, n_intervals=0)
], fluid=True)

app.layout = html.Div([
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content')
])


@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/base_cliente':
        return layout_base_cliente
    else:
        return layout_receita

def filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):
    filtered_df = df.copy()
    
    filtered_df = filtered_df[(filtered_df['data_do_pedido'] >= start_date) & (filtered_df['data_do_pedido'] <= end_date)]
    
    if dropdown_1:
        filtered_df = filtered_df[filtered_df['canal_de_finalizacao'].isin(dropdown_1)]
    if dropdown_2:
        filtered_df = filtered_df[filtered_df['nome_estrutura'].isin(dropdown_2)]
    if dropdown_3:
        filtered_df = filtered_df[filtered_df['origem_do_revendedor'].isin(dropdown_3)]
    if dropdown_4:
        filtered_df = filtered_df[filtered_df['atividade_na_base'].isin(dropdown_4)]
    if dropdown_5:
        filtered_df = filtered_df[filtered_df['segmentacao_\npapel'].isin(dropdown_5)]
    if dropdown_6:
        filtered_df = filtered_df[filtered_df['inadimplente'].isin(dropdown_6)]
    
    
    return filtered_df

@app.callback(
    [Output('card-1-pg1', 'className'), Output('dynamic-card', 'className')],
    [Input('card-1-pg1', 'children'), 
     Input('date-picker-range', 'start_date'),
     Input('date-picker-range', 'end_date'),
     Input('dropdown-1', 'value'),
     Input('dropdown-2', 'value'),
     Input('dropdown-3', 'value'),
     Input('dropdown-4', 'value'),
     Input('dropdown-5', 'value'),
     Input('dropdown-6', 'value')]
)
def update_icons(children, start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)
    grouped_df = filtered_df.groupby('data_do_pedido').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    
    total_realizado = grouped_df['realizado'].sum()
    total_meta = grouped_df['meta'].sum()
    
    if total_realizado < total_meta:
        card1_class = 'card-text1-red'
        dynamic_card_class = 'card card2'
    else:
        card1_class = 'card-text1-green'
        dynamic_card_class = 'card card3'
    
    return card1_class, dynamic_card_class

@app.callback(
    Output('card-1-pg1', 'children'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value')
)
def update_card_1(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)
    card_1 = filtered_df['realizado'].sum()
    return f"{card_1:,.0f}".replace(',', '.')


@app.callback(
    Output('card-2-pg1', 'children'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_new_users(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    new_users = filtered_df['meta'].sum()
    return f"{new_users:,.0f}".replace(',', '.')


@app.callback(
    Output('card-3-pg1', 'children'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_percentage_new_users(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    card_3 = filtered_df['media_unidades_compradas'].sum()
    return f"{card_3:,.0f}".replace(',', '.')


@app.callback(
    Output('card-4-pg1', 'children'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_engagement_rate(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    card_4 = filtered_df.groupby('pedido')['pedido'].nunique().sum()
    return f"{card_4:,.0f}".replace(',', '.')

@app.callback(
    Output('graph-1', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_1(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = filtered_df['data_do_pedido'].dt.date
    grouped_df = filtered_df.groupby('data_do_pedido').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()

    fig = go.Figure()
    
    fig.add_trace(
        go.Scatter(
            x=grouped_df['data_do_pedido'],
            y=grouped_df['realizado'],
            name='Valor Realizado',
            mode='lines',
            line=dict(color='#75D9D6', shape='spline'),
            yaxis='y'
            )
    )
    
    fig.add_trace(go.Scatter(
        x=grouped_df['data_do_pedido'],
        y=grouped_df['meta'],
        mode='lines',  
        name='Meta',
        line=dict(color='#3E9ABF', shape='spline'),
        opacity=0.5 
    ))
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None),
        yaxis2=dict(
            overlaying='y',
            side='right'
        ),
        legend=dict(
            x=0,  
            y=1.15, 
            traceorder='normal',
            orientation='h', 
            xanchor='left',  
            yanchor='top'   
        ),
        showlegend=True,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
        ) 
    )
    
    return fig

@app.callback(
    Output('graph-2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)
    grouped_df = filtered_df.groupby('segmentacao_\npapel').agg({'realizado': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
    
    category_colors = {
        'Platina': '#75D9D6',  
        'Rubi': '#DD578A',    
        'Ouro': '#DBC759',     
        'Prata': '#DBD3D3',   
        'Bronze': '#DD9A57'
    }

    fig = px.pie(
        grouped_df, 
        values='realizado', 
        names='segmentacao_\npapel',
        color='segmentacao_\npapel',  
        color_discrete_map=category_colors  
    )
    
    fig.update_traces(
        textposition='inside', 
        textinfo='percent+label'  
    )
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        showlegend=True,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig

@app.callback(
    Output('graph-3', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_3(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('nome_estrutura').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True).head(10)
    
    # Define colors based on condition
    colors = grouped_df.apply(lambda row: '#75D9D6' if row['realizado'] >= row['meta'] else '#DB5D5D', axis=1)
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=grouped_df['meta'],
        y=grouped_df['nome_estrutura'],
        name='Meta',
        orientation='h',
        marker=dict(color='#5C5C5C')  
    ))
    
    fig.add_trace(go.Bar(
        x=grouped_df['realizado'],
        y=grouped_df['nome_estrutura'],
        name='Realizado',
        orientation='h',
        marker=dict(color=colors)  # Apply conditional colors
    ))
    
    fig.update_layout(
        barmode='stack',
        xaxis=dict(title=None),
        yaxis=dict(title=None),
        showlegend=False,
        margin=dict(l=10, r=10, t=10, b=10),
        legend=dict(
            x=0,
            y=1.15,
            traceorder='normal',
            orientation='h',
            xanchor='left',
            yanchor='top'
        ),
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
        )
    )
    
    return fig
@app.callback(
    Output('graph-4', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_4(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('cod_r_finalizador_da_venda').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
     # Define colors based on condition
    colors = grouped_df.apply(lambda row: '#75D9D6' if row['realizado'] >= row['meta'] else '#DB5D5D', axis=1)   
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=grouped_df['meta'],
        y=grouped_df['cod_r_finalizador_da_venda'],
        name='Meta',
        orientation='h',
        marker=dict(color='#5C5C5C') 
    ))
    
    fig.add_trace(go.Bar(
        x=grouped_df['realizado'],
        y=grouped_df['cod_r_finalizador_da_venda'],
        name='Realizado',
        orientation='h',
        marker=dict(color=colors)  # Apply conditional colors
    ))
    
    fig.update_layout(
        barmode='stack', 
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None), 
        yaxis=dict(title=None), 
        showlegend=False,
        legend=dict(
            x=0, 
            y=1.15, 
            traceorder='normal',
            orientation='h', 
            xanchor='left', 
            yanchor='top'   
        ),
        plot_bgcolor='rgba(0,0,0,0)',  
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig
@app.callback(
    Output('graph-5', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_5(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('canal_de_finalizacao').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
     # Define colors based on condition
    colors = grouped_df.apply(lambda row: '#75D9D6' if row['realizado'] >= row['meta'] else '#DB5D5D', axis=1)   
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=grouped_df['canal_de_finalizacao'],
        y=grouped_df['meta'],
        name='Meta',
        orientation='v',
        marker=dict(color='#5C5C5C')  
    ))
    
    fig.add_trace(go.Bar(
        x=grouped_df['canal_de_finalizacao'],
        y=grouped_df['realizado'],
        name='Realizado',
        orientation='v',
        marker=dict(color=colors)  # Apply conditional colors
    ))
    
    fig.update_layout(
        barmode='stack',  
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None), 
        yaxis=dict(title=None), 
        showlegend=False,
        legend=dict(
            x=0, 
            y=1.15, 
            traceorder='normal',
            orientation='h',
            xanchor='left',  
            yanchor='top'   
        ),
        plot_bgcolor='rgba(0,0,0,0)',  
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig

@app.callback(
    Output('graph-6', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))


def update_graph_6(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('marca').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
      # Define colors based on condition
    colors = grouped_df.apply(lambda row: '#75D9D6' if row['realizado'] >= row['meta'] else '#DB5D5D', axis=1)  
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=grouped_df['marca'],
        y=grouped_df['meta'],
        name='Meta',
        orientation='v',
        marker=dict(color='#5C5C5C')  
    ))
    
    fig.add_trace(go.Bar(
        x=grouped_df['marca'],
        y=grouped_df['realizado'],
        name='Realizado',
        orientation='v',
        marker=dict(color=colors)  # Apply conditional colors
    ))
    
    fig.update_layout(
        barmode='stack',  
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None), 
        yaxis=dict(title=None), 
        showlegend=False,
        legend=dict(
            x=0,  
            y=1.15,  
            traceorder='normal',
            orientation='h',  
            xanchor='left', 
            yanchor='top'    
        ),
        plot_bgcolor='rgba(0,0,0,0)',  
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig

@app.callback(
    Output('graph-7', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_7(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = filtered_df['data_do_pedido'].dt.date

    grouped_df = filtered_df.groupby('data_do_pedido').agg({'realizado': 'sum', 'rr_credito_disponivel': 'sum'}).reset_index()
    
    fig = go.Figure()
    
    fig.add_trace(
        go.Scatter(
            x=grouped_df['data_do_pedido'],
            y=grouped_df['realizado'],
            mode='lines',
            line=dict(color='#75D9D6', shape='spline'),
            name='Valor Realizado'

        )
    )
    
    fig.add_trace(
        go.Scatter(
            x=grouped_df['data_do_pedido'],
            y=grouped_df['rr_credito_disponivel'],
            mode='lines',
            line=dict(color='#3E9ABF', shape='spline'),
            name='Crédito Disponível',
            yaxis='y2',
            opacity=0.5 
            )
    )
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None),
        yaxis2=dict(
            overlaying='y',
            side='right'
        ),
        legend=dict(
            x=0, 
            y=1.15,  
            traceorder='normal',
            orientation='h', 
            xanchor='left',  
            yanchor='top'   
        ),
        showlegend=True,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
        ) 
    )
    
    return fig

@app.callback(
    Output('graph-8', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_8(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = filtered_df['data_do_pedido'].dt.date

    grouped_df = filtered_df.groupby('data_do_pedido').agg({'realizado': 'sum', 'pedido_cancelado': 'sum'}).reset_index()
    
    fig = go.Figure()
    
    fig.add_trace(
        go.Scatter(
            x=grouped_df['data_do_pedido'],
            y=grouped_df['realizado'],
            mode='lines',
            line=dict(color='#75D9D6', shape='spline'),
            name='Valor Realizado'

        )
    )
    
    fig.add_trace(
        go.Scatter(
            x=grouped_df['data_do_pedido'],
            y=grouped_df['pedido_cancelado'],
            mode='lines',
            line=dict(color='#BF3E3E', shape='spline'),
            name='Pedido Cancelado',
            yaxis='y2',
            opacity=0.5 
            )
    )
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None),
        yaxis2=dict(
            overlaying='y',
            side='right'
        ),
        legend=dict(
            x=0,  
            y=1.15,  
            traceorder='normal',
            orientation='h',  
            xanchor='left',  
            yanchor='top'  
        ),
        showlegend=True,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
        ) 
    )
    
    return fig


@app.callback(
    Output('graph-9', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_9(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('cidade').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
    
    grouped_df['bubble_size'] = grouped_df['realizado'] + grouped_df['meta']
    custom_colors = ['#75D9D6', '#3E9ABF', '#E0E3E4', '#DB5D5D', '#DBC759']

    fig = go.Figure(data=[go.Scatter(
        x=grouped_df['realizado'], 
        y=grouped_df['meta'],
        mode='markers',
        marker=dict(
            size=grouped_df['bubble_size'],
            sizemode='area',
            sizeref=2.*max(grouped_df['bubble_size'])/(100.**2),
            sizemin=4,
            color=grouped_df['bubble_size'],
            colorscale=custom_colors,
            showscale=True,
        ),
        text=grouped_df['cidade']  
    )])
    
    # Ajustando o layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=40, b=20),
        plot_bgcolor='rgba(0,0,0,0)',  
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(
            gridcolor='#E0E0E0' 
        ),
        yaxis=dict(
            gridcolor='#E0E0E0'  
        ),
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
    ))
    
    return fig

@app.callback(
    Output('graph-10', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))
def update_graph_10(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    grouped_df = filtered_df.groupby('bairro').agg({'realizado': 'sum', 'meta': 'sum'}).reset_index()
    grouped_df = grouped_df.sort_values(by='realizado', ascending=True)
    
    grouped_df['bubble_size'] = grouped_df['realizado'] + grouped_df['meta']
    custom_colors = ['#75D9D6', '#3E9ABF', '#E0E3E4', '#DB5D5D', '#DBC759']

    fig = go.Figure(data=[go.Scatter(
        x=grouped_df['realizado'], 
        y=grouped_df['meta'],
        mode='markers',
        marker=dict(
            size=grouped_df['bubble_size'],
            sizemode='area',
            sizeref=2.*max(grouped_df['bubble_size'])/(100.**2),
            sizemin=4,
            color=grouped_df['bubble_size'],
            colorscale=custom_colors,
            showscale=True,
        ),
        text=grouped_df['bairro'] 
    )])
    
    # Ajustando o layout
    fig.update_layout(
        margin=dict(l=20, r=20, t=40, b=20),
        plot_bgcolor='rgba(0,0,0,0)',  
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis=dict(
            gridcolor='#E0E0E0'  
        ),
        yaxis=dict(
            gridcolor='#E0E0E0' 
        ),
        modebar=dict(
            bgcolor='white',
            color='#7F7F7F',
            activecolor='#A1A1A1'
    ))
    
    return fig

###### Pg 2

@app.callback(
    Output('graph-1-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_1_pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = pd.to_datetime(filtered_df['data_do_pedido']).dt.date
    
    grouped_df = filtered_df.groupby('inadimplente')['ajt_cod_des_revendedor'].nunique().reset_index(name='Clientes')
    
    # Calcular a soma dos valores de "Sim" e "Não"
    total_clientes = grouped_df['Clientes'].sum()
    new_row = pd.DataFrame({'inadimplente': ['Total'], 'Clientes': [total_clientes]})
    
    # Colocar a nova linha no início do DataFrame
    grouped_df = pd.concat([new_row, grouped_df], ignore_index=True)
    
    custom_colors = ['#74AAC8', '#75D9D6', '#DB5D5D',]  # Ajustar as cores
    
    fig = px.bar(grouped_df, x='inadimplente', y='Clientes', 
                 color='inadimplente', color_discrete_sequence=custom_colors)
        
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        xaxis_title='',
        yaxis_title='',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig



@app.callback(
    Output('graph-2-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_2pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = pd.to_datetime(filtered_df['data_do_pedido']).dt.date
    
    grouped_df = filtered_df.groupby('segmentacao_\npapel')['ajt_cod_des_revendedor'].nunique().reset_index(name='Clientes')
        
    category_colors = {
        'Platina': '#75D9D6',  
        'Rubi': '#DD578A',    
        'Ouro': '#DBC759',     
        'Prata': '#DBD3D3',   
        'Bronze': '#DD9A57'
    }

    fig = px.pie(
        grouped_df, 
        values='Clientes', 
        names='segmentacao_\npapel',
        color='segmentacao_\npapel',  
        color_discrete_map=category_colors  
    )
    
    fig.update_traces(
        textposition='inside', 
        textinfo='percent+label'  
    )
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        showlegend=True,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    
    return fig

@app.callback(
    Output('graph-3-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_3pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = pd.to_datetime(filtered_df['data_do_pedido']).dt.date
    
    grouped_df = filtered_df.groupby('atividade_na_base')['ajt_cod_des_revendedor'].nunique().reset_index(name='Clientes')
    grouped_df = grouped_df.sort_values(by='Clientes', ascending=True)
    
    fig = go.Figure(go.Bar(
        x=grouped_df['Clientes'],
        y=grouped_df['atividade_na_base'],
        orientation='h'
    ))
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None), 
        yaxis=dict(title=None),  
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    fig.update_traces(marker_color='#A4C4DC')
    return fig

@app.callback(
    Output('graph-4-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_4pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    filtered_df['data_do_pedido'] = pd.to_datetime(filtered_df['data_do_pedido']).dt.date
    
    grouped_df = filtered_df.groupby('marca')['ajt_cod_des_revendedor'].nunique().reset_index(name='Clientes')
    grouped_df = grouped_df.sort_values(by='Clientes', ascending=False)
    
    fig = go.Figure(go.Bar(
        x=grouped_df['marca'],
        y=grouped_df['Clientes'],
        orientation='v'
    ))
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis=dict(title=None), 
        yaxis=dict(title=None),  
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    fig.update_traces(marker_color='#75D9D6')
    return fig

@app.callback(
    Output('graph-5-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_5pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    
    
    grouped_df = filtered_df.groupby('ajt_cod_des_revendedor')['pedido'].nunique().reset_index()
    
    grouped_df.columns = ['ajt_cod_des_revendedor', 'distinct_orders']
    
    top_5_df = grouped_df.nlargest(5, 'distinct_orders')
    
    top_5_df = top_5_df.sort_values(by='distinct_orders', ascending=False)
    
    fig = go.Figure(go.Bar(
        x=top_5_df['distinct_orders'],
        y=top_5_df['ajt_cod_des_revendedor'],
        orientation='h'
    ))
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    fig.update_traces(marker_color='#74AAC8')
    return fig

@app.callback(
    Output('graph-6-pg2', 'figure'),
    Input('date-picker-range', 'start_date'),
    Input('date-picker-range', 'end_date'),
    Input('dropdown-1', 'value'),
    Input('dropdown-2', 'value'),
    Input('dropdown-3', 'value'),
    Input('dropdown-4', 'value'),
    Input('dropdown-5', 'value'),
    Input('dropdown-6', 'value'))

def update_graph_6pg2(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6):    
    filtered_df = filter_df(start_date, end_date, dropdown_1, dropdown_2, dropdown_3, dropdown_4, dropdown_5, dropdown_6)    

    grouped_df = filtered_df.groupby('ajt_cod_des_revendedor')['data_do_pedido'].nunique().reset_index()
    
    grouped_df.columns = ['ajt_cod_des_revendedor', 'frequencia']
    
    top_5_df = grouped_df.nlargest(5, 'frequencia')
    
    top_5_df = top_5_df.sort_values(by='frequencia', ascending=False)
    
    fig = go.Figure(go.Bar(
        x=top_5_df['frequencia'],
        y=top_5_df['ajt_cod_des_revendedor'],
        orientation='h'
    ))
    
    fig.update_layout(
        margin=dict(l=10, r=10, t=10, b=10),
        showlegend=False,
        plot_bgcolor='rgba(0,0,0,0)', 
        paper_bgcolor='rgba(0,0,0,0)',
        modebar={
            'bgcolor': 'white',
            'color': '#7F7F7F',
            'activecolor': '#A1A1A1'
        }
    )
    fig.update_traces(marker_color='#75D9D6')
    return fig



@app.callback(
    Output('chat-container', 'style'),
    Output('minimize-chatbot-button', 'children'),
    Input('open-chatbot-button', 'n_clicks'),
    Input('minimize-chatbot-button', 'n_clicks'),
    State('chat-container', 'style'),
    prevent_initial_call=True
)
def toggle_chatbot(open_clicks, minimize_clicks, chat_style):
    ctx = dash.callback_context
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if button_id == 'open-chatbot-button':
        return {'display': 'flex'}, ''
    elif button_id == 'minimize-chatbot-button':
        return {'display': 'none'}, 'Abrir Blue IA'
    else:
        return chat_style, ''

@app.callback(
    Output('chat-history', 'children'),
    Output('user-input', 'value'),
    Input('send-button', 'n_clicks'),
    Input('user-input', 'n_submit'),
    State('user-input', 'value'),
    State('chat-history', 'children'),
    prevent_initial_call=True
)
def update_chat(n_clicks, n_submit, user_message, chat_history):
    ctx = dash.callback_context
    button_id = ctx.triggered[0]['prop_id'].split('.')[0]

    if (button_id == 'send-button' and n_clicks > 0) or (button_id == 'user-input' and n_submit > 0):
        if chat_history is None:
            chat_history = []

        chat_history.append(html.Div(
            className='message-container_user',
            children=[
                html.Div([
                    html.P(user_message, className='user-message fade-in-message')
                ])
            ]
        ))

        chat_history.append(html.Div(
            id='typing-indicator',
            className='message-container',
            children=[
                html.Div([
                    html.P("Estou pensando...🤖", className='bot-message fade-in-message')
                ])
            ]
        ))

        threading.Thread(target=get_agent_response, args=(user_message,)).start()

        return chat_history, ''

    return dash.no_update, dash.no_update

@app.callback(
    Output('chat-history', 'children', allow_duplicate=True),
    Input('interval-component', 'n_intervals'),
    State('chat-history', 'children'),
    prevent_initial_call=True
)
def update_response(n_intervals, chat_history):
    global agent_response

    if agent_response is not None:
        chat_history = [msg for msg in chat_history if 'typing-indicator' not in msg['props'].get('id', '')]

        chat_history.append(html.Div(
            className='message-container',
            children=[
                html.Div([
                    html.P(agent_response, className='agent-message typing fade-in-message')
                ])
            ]
        ))
        agent_response = None

    return chat_history

if __name__ == '__main__':
    app.server.run(debug=False)
